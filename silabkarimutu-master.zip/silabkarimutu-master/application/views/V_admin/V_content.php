<div class="row">
   <div class="col-md-12 col-sm-12 col-xs-12">
            <p><h1>hallo dedi </h1></p>
       </div>
</div>
          <br />
</div>
     